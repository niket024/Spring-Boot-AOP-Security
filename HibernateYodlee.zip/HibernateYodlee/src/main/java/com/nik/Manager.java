package com.nik;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Manager
{
	public static void main(String[] args)
	{
		Configuration cfg = new Configuration();
		cfg.configure();
		SessionFactory factory = cfg.buildSessionFactory();
		Session session = factory.openSession();
		Transaction transaction = session.beginTransaction();
		Person p1 = new Person();
		p1.setId(123);
		p1.setfName("abc");
		p1.setlName("xyz");
		p1.setAge(24);
		session.save(p1);
		session.flush();
		transaction.commit();
		System.out.println("done");
		
	}
}
