package com.nik;


public class A {
	/*public  void test(){
		int i =90/0; 
	}*/
	A()
	{
		System.out.println("cons");
	}
	A(int i)
	{
		System.out.println("cons1");
	}
	{
		System.out.println("IIB");
	}
	public static void main(String[] args) {
		A a1 = new A();
		A a2 = new A(23);
	}
}
