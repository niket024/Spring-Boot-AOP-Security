package com.nik.model.test;

public class C
{
	public C()
	{
		System.out.println("C initialized");
	}

	public void doSomething()
	{
		System.out.println("Inside doSomething() method of 'C' bean.");
		
	}
}
