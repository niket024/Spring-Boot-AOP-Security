package com.nik.model.test;

public class B
{
	public B()
	{
		System.out.println("B initialized");
	}

	public void doSomething()
	{
		System.out.println("Inside doSomething() method of 'B' bean.");
		
	}
}
