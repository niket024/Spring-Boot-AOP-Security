# Spring Boot + JUnit 5 + Mockito

Article link : https://www.nik.com/spring-boot/spring-boot-junit-5-mockito/

## 1. How to start
```
$ mvn test
```
