package com.nik.core.services;

public interface HelloService {

    String get();

}
