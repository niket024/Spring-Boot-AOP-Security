package com.nik.core.repository;

public interface HelloRepository {
    String get();
}
