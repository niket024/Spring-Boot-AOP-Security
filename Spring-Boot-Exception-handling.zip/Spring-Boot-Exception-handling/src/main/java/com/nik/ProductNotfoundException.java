package com.nik;

public class ProductNotfoundException extends RuntimeException {
	private static final long serialVersionUID = 1L;
}